=============================NLPCC2018 Shared Task: Grammatical Error Correction=============================

Training data:

Format:
sens_id	num_correct	orig_sen	(corrections)

sen_id -- Id of the sentence in the essay, starting from 1.
num_correct -- Number of corrections.
orig_sen -- Original sentence.
corrections -- Corrected sentences (if num_correct is not equal to 0) by different correctors separated by a tab.
